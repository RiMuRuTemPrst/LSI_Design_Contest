// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xhw_conv7x7.h"

extern XHw_conv7x7_Config XHw_conv7x7_ConfigTable[];

#ifdef SDT
XHw_conv7x7_Config *XHw_conv7x7_LookupConfig(UINTPTR BaseAddress) {
	XHw_conv7x7_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XHw_conv7x7_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XHw_conv7x7_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XHw_conv7x7_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_conv7x7_Initialize(XHw_conv7x7 *InstancePtr, UINTPTR BaseAddress) {
	XHw_conv7x7_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_conv7x7_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_conv7x7_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XHw_conv7x7_Config *XHw_conv7x7_LookupConfig(u16 DeviceId) {
	XHw_conv7x7_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XHW_CONV7X7_NUM_INSTANCES; Index++) {
		if (XHw_conv7x7_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XHw_conv7x7_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XHw_conv7x7_Initialize(XHw_conv7x7 *InstancePtr, u16 DeviceId) {
	XHw_conv7x7_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XHw_conv7x7_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XHw_conv7x7_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

