// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XHW_CONV7X7_H
#define XHW_CONV7X7_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xhw_conv7x7_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XHw_conv7x7_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XHw_conv7x7;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XHw_conv7x7_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XHw_conv7x7_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XHw_conv7x7_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XHw_conv7x7_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XHw_conv7x7_Initialize(XHw_conv7x7 *InstancePtr, UINTPTR BaseAddress);
XHw_conv7x7_Config* XHw_conv7x7_LookupConfig(UINTPTR BaseAddress);
#else
int XHw_conv7x7_Initialize(XHw_conv7x7 *InstancePtr, u16 DeviceId);
XHw_conv7x7_Config* XHw_conv7x7_LookupConfig(u16 DeviceId);
#endif
int XHw_conv7x7_CfgInitialize(XHw_conv7x7 *InstancePtr, XHw_conv7x7_Config *ConfigPtr);
#else
int XHw_conv7x7_Initialize(XHw_conv7x7 *InstancePtr, const char* InstanceName);
int XHw_conv7x7_Release(XHw_conv7x7 *InstancePtr);
#endif

void XHw_conv7x7_Start(XHw_conv7x7 *InstancePtr);
u32 XHw_conv7x7_IsDone(XHw_conv7x7 *InstancePtr);
u32 XHw_conv7x7_IsIdle(XHw_conv7x7 *InstancePtr);
u32 XHw_conv7x7_IsReady(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_EnableAutoRestart(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_DisableAutoRestart(XHw_conv7x7 *InstancePtr);

void XHw_conv7x7_Set_X(XHw_conv7x7 *InstancePtr, u64 Data);
u64 XHw_conv7x7_Get_X(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_Set_W(XHw_conv7x7 *InstancePtr, u64 Data);
u64 XHw_conv7x7_Get_W(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_Set_B(XHw_conv7x7 *InstancePtr, u64 Data);
u64 XHw_conv7x7_Get_B(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_Set_Y(XHw_conv7x7 *InstancePtr, u64 Data);
u64 XHw_conv7x7_Get_Y(XHw_conv7x7 *InstancePtr);

void XHw_conv7x7_InterruptGlobalEnable(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_InterruptGlobalDisable(XHw_conv7x7 *InstancePtr);
void XHw_conv7x7_InterruptEnable(XHw_conv7x7 *InstancePtr, u32 Mask);
void XHw_conv7x7_InterruptDisable(XHw_conv7x7 *InstancePtr, u32 Mask);
void XHw_conv7x7_InterruptClear(XHw_conv7x7 *InstancePtr, u32 Mask);
u32 XHw_conv7x7_InterruptGetEnabled(XHw_conv7x7 *InstancePtr);
u32 XHw_conv7x7_InterruptGetStatus(XHw_conv7x7 *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
