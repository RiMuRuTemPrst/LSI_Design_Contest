// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xhw_conv7x7.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XHw_conv7x7_CfgInitialize(XHw_conv7x7 *InstancePtr, XHw_conv7x7_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XHw_conv7x7_Start(XHw_conv7x7 *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL) & 0x80;
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XHw_conv7x7_IsDone(XHw_conv7x7 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XHw_conv7x7_IsIdle(XHw_conv7x7 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XHw_conv7x7_IsReady(XHw_conv7x7 *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XHw_conv7x7_EnableAutoRestart(XHw_conv7x7 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XHw_conv7x7_DisableAutoRestart(XHw_conv7x7 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_AP_CTRL, 0);
}

void XHw_conv7x7_Set_X(XHw_conv7x7 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_X_DATA, (u32)(Data));
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_X_DATA + 4, (u32)(Data >> 32));
}

u64 XHw_conv7x7_Get_X(XHw_conv7x7 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_X_DATA);
    Data += (u64)XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_X_DATA + 4) << 32;
    return Data;
}

void XHw_conv7x7_Set_W(XHw_conv7x7 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_W_DATA, (u32)(Data));
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_W_DATA + 4, (u32)(Data >> 32));
}

u64 XHw_conv7x7_Get_W(XHw_conv7x7 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_W_DATA);
    Data += (u64)XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_W_DATA + 4) << 32;
    return Data;
}

void XHw_conv7x7_Set_B(XHw_conv7x7 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_B_DATA, (u32)(Data));
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_B_DATA + 4, (u32)(Data >> 32));
}

u64 XHw_conv7x7_Get_B(XHw_conv7x7 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_B_DATA);
    Data += (u64)XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_B_DATA + 4) << 32;
    return Data;
}

void XHw_conv7x7_Set_Y(XHw_conv7x7 *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_Y_DATA, (u32)(Data));
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_Y_DATA + 4, (u32)(Data >> 32));
}

u64 XHw_conv7x7_Get_Y(XHw_conv7x7 *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_Y_DATA);
    Data += (u64)XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_Y_DATA + 4) << 32;
    return Data;
}

void XHw_conv7x7_InterruptGlobalEnable(XHw_conv7x7 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_GIE, 1);
}

void XHw_conv7x7_InterruptGlobalDisable(XHw_conv7x7 *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_GIE, 0);
}

void XHw_conv7x7_InterruptEnable(XHw_conv7x7 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_IER);
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_IER, Register | Mask);
}

void XHw_conv7x7_InterruptDisable(XHw_conv7x7 *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_IER);
    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_IER, Register & (~Mask));
}

void XHw_conv7x7_InterruptClear(XHw_conv7x7 *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XHw_conv7x7_WriteReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_ISR, Mask);
}

u32 XHw_conv7x7_InterruptGetEnabled(XHw_conv7x7 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_IER);
}

u32 XHw_conv7x7_InterruptGetStatus(XHw_conv7x7 *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XHw_conv7x7_ReadReg(InstancePtr->Control_BaseAddress, XHW_CONV7X7_CONTROL_ADDR_ISR);
}

